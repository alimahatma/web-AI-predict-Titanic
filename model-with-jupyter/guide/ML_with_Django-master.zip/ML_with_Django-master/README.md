We created a Machine Learning web application using Django.
The aim was to predict the survival of passengers using Logistic Regression.
Django can be used to create awesome web applications as we have demonstrated.


Run the model.py to generate the .pkl files that will be used for prediction
